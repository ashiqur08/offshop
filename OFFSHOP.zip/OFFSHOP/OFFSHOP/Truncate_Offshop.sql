truncate table DueDetails
truncate table DueMaster
truncate table GodownBreakage
truncate table GodownLastQty
truncate table GuestMaster
truncate table PurchaseDetails
truncate table PurchaseMaster
truncate table SaveProductDetails
truncate table SaveProductMaster
truncate table GodownStock
truncate table Offshop_Stock
truncate table OffshopBreakage
-----------
truncate table EmployeeMaster
truncate table EmployeeHotelMaster
truncate table PermissionMenuOffshop
truncate table PermissionUserOffshop
