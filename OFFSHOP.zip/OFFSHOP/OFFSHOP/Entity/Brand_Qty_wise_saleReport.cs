﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
namespace Entity
{
    public class Brand_Qty_wise_saleReport
    {
    }
}
